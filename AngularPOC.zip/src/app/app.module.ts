import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ModalPopUpComponent } from './Components/modal-pop-up/modal-pop-up.component';
import { CommonComponent } from './Components/common/common.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { NgxUiLoaderModule } from  'ngx-ui-loader';
import { HeaderComponent } from './Components/header/header.component';
import { FooterComponent } from './Components/footer/footer.component';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';

// const ngxUiLoader:  NgxUiLoaderConfig  =  {
//   bgsColor:  '#5577a4',
//   bgsPosition:  POSITION.centerCenter,
//   bgsSize:  80,
//   bgsOpacity:  1,
//   bgsType:  SPINNER.ballSpinClockwise
// };


@NgModule({
  declarations: [
    AppComponent,    
    ModalPopUpComponent,
    CommonComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule, AppRoutingModule, HttpClientModule,
    NgxUiLoaderModule,
    NgbModalModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
