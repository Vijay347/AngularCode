import { Component, OnInit } from '@angular/core';
import { IUserDetails } from '../../commonModel/common/common.component';
import { CommonserviceComponent } from '../../service/commonservice/commonservice.component';

@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.css']
})
export class CommonComponent implements OnInit {

  userDetail: IUserDetails = {
    userId: 0,
    userName: "",
    password: ""
  }

  constructor(private appService: CommonserviceComponent) { }

  resultList = {}

  ngOnInit() { 
    this.GetuserDetails();
    this.GetPostUserDetails(this.userDetail);
  }

  public GetuserDetails() {
    this.appService.getLoginDetails().subscribe(data => {
      this.resultList = data;
    });
  };


  public GetPostUserDetails(userDetail) {
    var vUser = {
      'userId': userDetail.userId
    }
    this.appService.getUserDetails(vUser).subscribe(data => {
      this.resultList = data;
    });
  };

}
