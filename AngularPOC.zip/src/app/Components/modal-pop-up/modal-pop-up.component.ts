import { Component, OnInit } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-modal-pop-up',
  templateUrl: './modal-pop-up.component.html',
  styleUrls: ['./modal-pop-up.component.css'],
  providers: [NgbModalConfig, NgbModal],
})
export class ModalPopUpComponent {

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal
  ) {
    
    // comment below line for allow outside click
      config.backdrop = 'static';
      config.keyboard = false;
  }

  clickModal(content) {  
    this.modalService.open(content, { centered: true });
  };

  closeMP() {
    this.modalService.dismissAll();
  };

}
