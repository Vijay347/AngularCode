import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonserviceComponent } from './commonservice.component';

describe('CommonserviceComponent', () => {
  let component: CommonserviceComponent;
  let fixture: ComponentFixture<CommonserviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonserviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
