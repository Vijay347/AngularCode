import { Component, OnInit ,Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

var vURL = "http://localhost:52071/";

const httpOptions = {
  headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Credentials':'true',
      'Access-Control-Allow-Methods':'*',
      'Access-Control-Allow-Headers':'Origin, X-Requested-With, Content-Type, Accept',
      'Content-Type': 'application/json; charset=utf-8'
  })
};


@Injectable({
  providedIn: 'root'
})

export class CommonserviceComponent {

  constructor(public http: HttpClient) { }

   getLoginDetails() {
    return this.http.post(vURL + "Login/getLoginDetails",httpOptions);
  }

   getUserDetails(userDetail) {
    return this.http.post(vURL + "Login/getLoginDetails",userDetail,httpOptions);
  }

}
   
   