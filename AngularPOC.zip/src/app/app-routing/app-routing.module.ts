import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ModalPopUpComponent } from '../Components/modal-pop-up/modal-pop-up.component';
import { CommonComponent } from '../Components/common/common.component';


const routes: Routes = [
   { path: 'Common', component: CommonComponent },
   { path: 'ModalPopUp', component: ModalPopUpComponent }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }

