export interface IUserDetails {
  userId?: number
  userName?: string;
  password?: string;

}