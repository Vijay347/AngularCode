const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const validator = require('validator');

const UserSchema = mongoose.Schema({
    name: {
        type : String,
        required: true,
        minlength: 3
    },
    email: {
        type : String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        validate: validator.isEmail
    },
    team: {
        type : String,
        required: true
    },
    password: {
        type : String,
        required: true
    },
    role: { 
        type: String,
        enum: ['ADMIN','USER'] 
    }
}, {
    timestamps: true
});

UserSchema.pre('save', function (next) {
    if (this.isModified('password')) {
        this.password = bcrypt.hashSync(this.password, 10);
    }
    next();
});

UserSchema.methods.verifyPassword = function(passwordString) {
    return bcrypt.compareSync(passwordString, this.password);
};

module.exports = mongoose.model('User',UserSchema,'users');