module.exports = {
    HOME: '/'
};