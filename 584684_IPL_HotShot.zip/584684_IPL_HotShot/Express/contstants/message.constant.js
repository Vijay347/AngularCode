module.exports = {
    UNEXPECTED_ERROR: 'An unexpected error has occurred.',
    REGISTERED: 'You have been successfully registered.',
    WRONG_CREDENTIALS: 'These credentials do not match our records.',
    PASSWORD_CHANGED: 'Your password has been changed successfully!',
    PROFILE_UPDATED: 'Profile updated successfully!',
    EMAIL_EXISTS: 'Email already exists.',
    MOBILE_EXISTS: 'Mobile Number already exists.',
    SESSION_EXPIRED: 'Your session has expired. Please log in again.',
    SAVED: 'Saved Successfully!',
    UPDATED: 'Updated Successfully!',
    DELETED: 'Deleted Successfully!'
};