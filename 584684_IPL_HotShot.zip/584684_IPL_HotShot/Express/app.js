const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const helmet = require('helmet');
const compression = require('compression');
const logger = require('morgan');
const passport = require('passport');
const errorHandler = require('./helpers/error.handler');
const authRouter = require('./routes/auth.routes');
const cricketRouter = require('./routes/cricket.routes');
const database = require('./support/database.connection');
const authantication = require('./support/authantication.auth');

const app = express();
dotenv.config()
app.use(helmet());
app.use(compression());
app.use(logger('dev'));
app.set('json spaces', 2);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(passport.initialize());
app.use(express.static(path.join(__dirname, 'public'),{
    maxAge: '1y'
}));

database.initialize();
authantication.initialize();

app.use('/api/auth',authRouter);
app.use('/api/cricket',cricketRouter);

app.get('/api/**', (req, res) => { 
    res.status(400).json({ message: 'Invalid API request', success : false });
});
app.get('*',(req, res) => {
    res.sendfile('public/index.html');
});

app.use(errorHandler);

const port = process.env.NODE_ENV === 'production' ? process.env.PORT : 80;
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});