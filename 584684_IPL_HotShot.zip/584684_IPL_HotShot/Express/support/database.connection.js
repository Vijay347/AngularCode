exports.initialize = function(){
    const mongoose = require('mongoose');
    mongoose.set('useFindAndModify', false);
    mongoose.Promise = global.Promise;
    mongoose.connect(process.env.MONGODB_URI, {
        useCreateIndex: true,
        useNewUrlParser: true
    }).then(() => {
        console.log('Successfully connected to the database');    
    }).catch(err => {
        console.log('Could not connect to the database. Exiting now...', err);
        process.exit();
    });
}