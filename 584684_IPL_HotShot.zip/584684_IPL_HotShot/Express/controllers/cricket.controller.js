const Match = require('../models/match.model');
const Delivery = require('../models/delivery.model');
const ObjectID = require('mongoose').Types.ObjectId;

exports.getDashboard = (req, res, next) => {
    Match.aggregate([
        { 
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostRuns : [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            season: '$_id.season',
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 5
                    }
                ],
                highestScores: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 5
                    }
                ],
                battingAverage: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    { 
                        $limit: 5
                    }
                ],
                batsmanRanking: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    {
                        $group : {
                            _id: { },
                            items: { 
                                $push: '$$ROOT'
                            }
                        }
                    },
                    { 
                        $unwind: { 
                            path: '$items',
                            includeArrayIndex: 'items.rank'
                        } 
                    },
                    {
                        $project : {
                            batsman: '$items.batsman',
                            team: '$items.team',
                            rank: { 
                                $add: [ '$items.rank', 1 ] 
                            },
                            _id: 0
                        }
                    },
                    { 
                        $limit: 5
                    }
                ],
                mostCenturies: [
                    {
                        $match :{
                            season: req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            centuries: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $gt: ['$runs',99]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            centuries: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            centuries: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            centuries : -1
                        }
                    },
                    { 
                        $limit: 5
                    }
                ],
                mostFifties: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fifties: { 
                                $sum: {
                                    $cond: [
                                        {
                                            $and : [
                                                { 
                                                    $lt: ['$runs',100]
                                                },
                                                { 
                                                    $gt: ['$runs',20]
                                                }
                                            ]
                                        },
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fifties: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            fifties: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fifties : -1
                        }
                    },
                    { 
                        $limit: 5
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                highestScores: 1,
                mostRuns: 1,
                battingAverage: 1,
                batsmanRanking: 1,
                mostCenturies: 1,
                mostFifties: 1
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMatches = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                matches: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $sort : {
                            season: 1,
                            id : 1
                        }
                    }
                ],
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                team1: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $group : {
                            _id: '$team1'
                        }
                    }
                ],
                team2: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $group : {
                            _id: '$team2'
                        }
                    }
                ]
            }
        },
        {
            $project: {
                matches: 1,
                seasons: '$seasons._id',
                teams:{
                    $setUnion:['$team1._id','$team2._id']
                }
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostRuns = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostRuns: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum: '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum: '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                mostRuns: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getHighestScores = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                highScores: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                highScores: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getBatttingAverage = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                battingAverages: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                battingAverages: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getBatsmanRanking = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRankings: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    {
                        $group : {
                            _id: { },
                            items: { 
                                $push: '$$ROOT'
                            }
                        }
                    },
                    { 
                        $unwind: { 
                            path: '$items',
                            includeArrayIndex: 'items.rank'
                        } 
                    },
                    {
                        $project : {
                            season: '$items.season',
                            team: '$items.team',
                            batsman: '$items.batsman',
                            matches: '$items.matches',
                            runs: '$items.runs',
                            average: '$items.average',
                            rank: { 
                                $add: [ '$items.rank', 1 ] 
                            },
                            _id: 0
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    {
                        $group : {
                            _id: { },
                            items: { 
                                $push: '$$ROOT'
                            }
                        }
                    },
                    { 
                        $unwind: { 
                            path: '$items',
                            includeArrayIndex: 'items.rank'
                        } 
                    },
                    {
                        $project : {
                            season: '$items.season',
                            team: '$items.team',
                            batsman: '$items.batsman',
                            matches: '$items.matches',
                            runs: '$items.runs',
                            average: '$items.average',
                            rank: { 
                                $add: [ '$items.rank', 1 ] 
                            },
                            _id: 0
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRankings: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostCenturies = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostCenturies: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            centuries: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $gt: ['$runs',99]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            centuries: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            centuries: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            centuries : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            centuries: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $gt: ['$runs',99]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            centuries: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            centuries: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            centuries : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                mostCenturies: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostFifties = (req, res, next) => {
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostFifties: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fifties: { 
                                $sum: {
                                    $cond: [
                                        {
                                            $and : [
                                                { 
                                                    $lt: ['$runs',100]
                                                },
                                                { 
                                                    $gt: ['$runs',20]
                                                }
                                            ]
                                        },
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fifties: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fifties: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fifties : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fifties: { 
                                $sum: {
                                    $cond: [
                                        {
                                            $and : [
                                                { 
                                                    $lt: ['$runs',100]
                                                },
                                                { 
                                                    $gt: ['$runs',20]
                                                }
                                            ]
                                        },
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fifties: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fifties: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fifties : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                mostFifties: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostSixes = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostSixes: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            sixes:{
                                $sum : '$sixes'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            sixes: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            sixes: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            sixes : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            sixes:{
                                $sum : '$sixes'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            sixes: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            sixes: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            sixes : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                mostSixes: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostFours = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                mostFours: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fours:{
                                $sum : '$fours'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fours: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fours: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fours : -1
                        }
                    },
                    { 
                        $limit: 20
                    }
                ],
                teams: [
                    {
                        $match :{
                            season : req.query.season ? parseInt(req.query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fours:{
                                $sum : '$fours'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fours: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fours: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fours : -1
                        }
                    },
                    { 
                        $limit: 20
                    },
                    {
                        $group:{
                            _id: '$team'   
                        }
                    },
                    {
                        $sort:{
                            _id: -1   
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                mostFours: 1,
                teams: '$teams._id'
            }
        }
    ]).then((response)=>{
        response[0].season = req.query.season ? parseInt(req.query.season) : 2019;
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMatchDetails = (req, res, next) => {
    Match.aggregate([
        {
            $match :{
                id: parseInt(req.params.id)
            }
        },
        {
            $facet: {
                matches: [
                   {
                        $match : {

                        }
                   }
                ],
                battings: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                matchId: '$deliveries.match_id',
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            },
                            balls: { 
                                $sum: 1 
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            extras: { 
                                $sum: '$deliveries.extra_runs'
                            },
                            totalRuns: { 
                                $sum: '$deliveries.total_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            matchId: '$_id.matchId',
                            totalRuns: {
                                $subtract : ['$totalRuns','$extras']
                            },
                            runs: {
                                $subtract : ['$runs','$extras']
                            },
                            balls: 1,
                            fours: 1,
                            sixes: 1,
                            extras: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    }
                ],
                bowlings: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.bowling_team',
                                bowler: '$deliveries.bowler',
                                overs: '$deliveries.over',
                                matchId: '$deliveries.match_id',
                                overs: {
                                    $sum : 1
                                }
                            },
                            runs: {
                                $sum : '$deliveries.total_runs'
                            },
                            wickets: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $ne: ['$deliveries.player_dismissed','']
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            dots: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.total_runs',0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            extras: { 
                                $sum: '$deliveries.extra_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                bowler: '$_id.bowler',
                                matchId: '$_id.matchId'
                            },
                            overs: {
                                $sum : '$_id.overs'
                            },
                            runs: {
                                $sum : '$runs'
                            },
                            maidens: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: [{
                                                $sum : '$runs'
                                            },0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            wickets: { 
                                $sum: '$wickets'
                            },
                            dots: { 
                                $sum: '$dots'
                            },
                            extras: { 
                                $sum: '$extras'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            bowler: '$_id.bowler',
                            team: '$_id.team',
                            matchId: '$_id.matchId',
                            overs: '$overs',
                            runs: {
                                $subtract : ['$runs','$extras']
                            },
                            maidens: 1,
                            wickets: 1,
                            dots: 1,
                            extras: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            overs : -1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                matches: 1,
                battings: 1,
                bowlings: 1
            }
        }
    ]).then((response)=>{
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getTeamComparison = (req, res, next) => {
    Match.aggregate([
        {
            $match :{
                season: parseInt(req.query.season),
                team1 : {
                    $in : [req.query.team1,req.query.team2]
                },
                team2 : {
                    $in : [req.query.team1,req.query.team2]
                }
            }
        },
        {
            $facet: {
                matches: [
                   {
                        $match : {

                        }
                   }
                ],
                battings: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                matchId: '$deliveries.match_id',
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            },
                            balls: { 
                                $sum: 1 
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            extras: { 
                                $sum: '$deliveries.extra_runs'
                            },
                            totalRuns: { 
                                $sum: '$deliveries.total_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            matchId: '$_id.matchId',
                            totalRuns: {
                                $subtract : ['$totalRuns','$extras']
                            },
                            runs: {
                                $subtract : ['$runs','$extras']
                            },
                            balls: 1,
                            fours: 1,
                            sixes: 1,
                            extras: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    }
                ],
                bowlings: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.bowling_team',
                                bowler: '$deliveries.bowler',
                                overs: '$deliveries.over',
                                matchId: '$deliveries.match_id',
                                overs: {
                                    $sum : 1
                                }
                            },
                            runs: {
                                $sum : '$deliveries.total_runs'
                            },
                            wickets: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $ne: ['$deliveries.player_dismissed','']
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            dots: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.total_runs',0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            extras: { 
                                $sum: '$deliveries.extra_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                bowler: '$_id.bowler',
                                matchId: '$_id.matchId'
                            },
                            overs: {
                                $sum : '$_id.overs'
                            },
                            runs: {
                                $sum : '$runs'
                            },
                            maidens: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: [{
                                                $sum : '$runs'
                                            },0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            wickets: { 
                                $sum: '$wickets'
                            },
                            dots: { 
                                $sum: '$dots'
                            },
                            extras: { 
                                $sum: '$extras'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            bowler: '$_id.bowler',
                            team: '$_id.team',
                            matchId: '$_id.matchId',
                            overs: '$overs',
                            runs: {
                                $subtract : ['$runs','$extras']
                            },
                            maidens: 1,
                            wickets: 1,
                            dots: 1,
                            extras: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            overs : -1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                matches: 1,
                battings: 1,
                bowlings: 1
            }
        }
    ]).then((response)=>{
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getScores = (req, res, next) => {
    Delivery.aggregate([
        {
            $match :{
                match_id : parseInt(req.params.matchId)
            }
        }
    ]).then((response)=>{
        res.json(response);
    }).catch((error)=>{
        next(error);
    });
};

exports.getScore = (req, res, next) => {
    Delivery.aggregate([
        {
            $match :{
                match_id : parseInt(req.params.matchId)
            }
        },
        {
            $facet: {
                batsmans: [
                    {
                        $group : {
                            _id: {
                                team: '$batting_team',
                                batsman: '$batsman'
                            }
                        }
                    }, 
                    {
                        $project: {
                            team: '$_id.team',
                            player: '$_id.batsman'
                        }
                    }
                ],
                bowlers: [
                    {
                        $group : {
                            _id: {
                                team: '$bowling_team',
                                bowler: '$bowler'
                            }
                        }
                    }, 
                    {
                        $project: {
                            team: '$_id.team',
                            player: '$_id.bowler'
                        }
                    }
                ],
                deliveries: [
                    {
                        $match :{
                            _id : ObjectID(req.params.id)
                        }
                    }
                ]
            }
        },
        {
            $project: {
                players:{
                    $setUnion:['$batsmans','$bowlers']
                },
                delivery: { 
                    $arrayElemAt: ["$deliveries", 0] 
                },
            }
        }
    ]).then((response)=>{
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.updateScore = (req, res, next) => {
    Delivery.findOneAndUpdate({
        _id: ObjectID(req.params.id),
        match_id: req.params.matchId
    },{
        $set: {
            batsman: req.body.batsman,
            non_striker: req.body.non_striker,
            bowler: req.body.bowler,
            is_super_over: req.body.is_super_over,
            wide_runs: req.body.wide_runs,
            bye_runs: req.body.bye_runs,
            legbye_runs: req.body.legbye_runs,
            noball_runs: req.body.noball_runs,
            penalty_runs: req.body.penalty_runs,
            batsman_runs: req.body.batsman_runs,
            extra_runs: req.body.extra_runs,
            total_runs: req.body.total_runs,
            player_dismissed: req.body.player_dismissed,
            dismissal_kind: req.body.dismissal_kind,
            fielder: req.body.fielder
        }
    }).lean().then((response)=>{
        res.json({ message: 'Saved Successfully!', redirect: `/manage-scores/${response.match_id}`, success: true });
    }).catch((error)=>{
        next(error);
    });
};

exports.getFavouriteTeams = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                team1: [
                    {
                        $group : {
                            _id: '$team1'
                        }
                    }
                ],
                team2: [
                    {
                        $group : {
                            _id: '$team2'
                        }
                    }
                ]
            }
        },
        {
            $project: {
                teams:{
                    $setUnion:['$team1._id','$team2._id']
                }
            }
        }
    ]).then((response)=>{
        res.json(response[0].teams);
    }).catch((error)=>{
        next(error);
    });
};

exports.getTeams = (req, res, next) => {
    Match.aggregate([
        {
            $facet: {
                team1: [
                    {
                        $group : {
                            _id: {
                                team: '$team1',
                                season: '$season'
                            }
                        }
                    }, 
                    {
                        $project: {
                            name: '$_id.team',
                            season: '$_id.season',
                            _id: 0
                        }
                    }
                ],
                team2: [
                    {
                        $group : {
                            _id: {
                                team: '$team2',
                                season: '$season'
                            }
                        }
                    }, 
                    {
                        $project: {
                            name: '$_id.team',
                            season: '$_id.season',
                            _id: 0
                        }
                    }
                ],
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                teams:{
                    $setUnion:['$team1','$team2']
                },
                seasons: '$seasons._id'
            }
        }
    ]).then((response)=>{
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getPlayers = (req, res, next) => {
    Match.aggregate([
        {
            $match :{
                season : parseInt(req.params.season),
                $or : [
                    { 
                        team1: req.params.team
                    },
                    { 
                        team2: req.params.team
                    }
                ]
            }
        },
        {
            $facet: {
                player1: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $match: {
                            'deliveries.batting_team' : req.params.team
                        }
                    },
                    {
                        $group : {
                            _id: {
                                name: '$deliveries.batsman',
                                team: '$deliveries.batting_team',
                                season: '$season'
                            }
                        }
                    },
                    {
                        $project : {
                            name: '$_id.name',
                            team: '$_id.team',
                            season: '$_id.season',
                            _id: 0
                        }
                    }
                ],
                player2: [
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $match: {
                            'deliveries.bowling_team' : req.params.team
                        }
                    },
                    {
                        $group : {
                            _id: {
                                name: '$deliveries.bowler',
                                team: '$deliveries.bowling_team',
                                season: '$season'
                            }
                        }
                    },
                    {
                        $project : {
                            name: '$_id.name',
                            team: '$_id.team',
                            season: '$_id.season',
                            _id: 0
                        }
                    }
                ]
            }
        },
        {
            $project: {
                players:{
                    $setUnion:['$player1','$player2']
                }
            }
        },
        {
            $sort: {
                players: -1
            }
        }
    ]).then((response)=>{
        res.json(response[0]);
    }).catch((error)=>{
        next(error);
    });
};