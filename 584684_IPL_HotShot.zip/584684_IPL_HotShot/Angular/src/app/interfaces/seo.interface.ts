export interface Title{
    title: string,
    subTitle: string
}