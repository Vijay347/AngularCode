import { Status } from './status.interface';

//User
export interface User {
    emailVerified: boolean;
    mobileVerified: boolean;
    _id: string;
    name: string;
    email: string;
    mobile: string;
    password: string;
    roles: any[];
    createdAt: string;
    updatedAt: string;
    __v: number;
}

//JWT
export interface Jwt {
    token:     string;
    expiresIn: number;
}

//Register
export interface Register {
    name: string;
    mobile: string;
    email: string;
    password: string;
    confirmPassword: string;
    "g-recaptcha-response": string;
}

//TokenResponse
export interface TokenResponse extends Jwt, Status {
    user: User
}

//OTP
export interface OTP {
    otp: string,
    mobile: string;
}

//ForgotPassword
export interface ForgotPassword {
    mobile: string;
    "g-recaptcha-response": string;
}

//Login
export interface Login {
    name: string;
    password: string;
}

//ResetPassword
export interface ResetPassword {
    password: string;
    confirmPassword: string;
}