import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-batsman-score',
  templateUrl: './batsman-score.component.html',
  styleUrls: ['./batsman-score.component.scss']
})
export class BatsmanScoreComponent implements OnInit {

  batsmanRuns: any[] = [];
  seasons: any[] = [];
  form:FormGroup;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {

   }

  ngOnInit() {
    this.setForm();
    this.queryParamsChange();
  }

  setForm(){
    this.form = this.fb.group({
      search: null,
      season: null
    });
    this.form.patchValue(this.route.snapshot.queryParams);
  }

  loadData(queryParams){
    this.cricketService.getBatsmanRuns(queryParams).subscribe((response)=>{
      this.seoService.setTitle('Batsman Runs(Top 25 Players)');
      this.batsmanRuns = response.batsmanRuns;
      this.seasons = response.seasons;
      if(this.batsmanRuns.length){
        this.form.get('season').patchValue(this.batsmanRuns[0].season);
      }else{
        this.form.get('season').patchValue(null);
      }
    });
  }

  queryParamsChange():void{
    this.route.queryParams.subscribe((queryParams)=>{
      this.loadData(queryParams);
    });
  }

  doSearch(){
    this.router.navigate(['/batsman-runs'], { queryParams: JSON.parse(JSON.stringify(this.form.value)), queryParamsHandling: 'merge' });
  }
}
