import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  matches: any[] = [];
  seasons: any[] = [];
  total:number = 0;
  page:number;
  form:FormGroup;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {
    this.page = this.route.snapshot.queryParams.page ? this.route.snapshot.queryParams.page : 1;
   }

  ngOnInit() {
    this.seoService.setTitle('IPL Matches');
    this.setForm();
    this.queryParamsChange();
  }

  setForm(){
    this.form = this.fb.group({
      season: null,
      search: null
    });
    
  }

  loadData(queryParams){
    this.cricketService.getMatches(queryParams).subscribe((response)=>{
      this.matches = response.matches;
      this.seasons = response.seasons;
      this.total = response.total;
      this.form.get('season').patchValue(this.matches[0].season);
    });
  }

  onPageChange() : void{
    this.router.navigate(['/dashboard'], { queryParams: { page : this.page }, queryParamsHandling: 'merge' });
  }

  queryParamsChange():void{
    this.route.queryParams.subscribe((queryParams)=>{
      this.loadData(queryParams);
    });
  }

  doSearch(){
    let queryParams = JSON.parse(JSON.stringify(this.form.value));
    this.page = 1;
    queryParams.page = 1;
    this.router.navigate(['/dashboard'], { queryParams: queryParams, queryParamsHandling: 'merge' });
  }

}
