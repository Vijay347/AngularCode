import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidator } from '@services/custom-validator.service';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  form: FormGroup;
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private router:Router, private auth:AuthService, private alert:AlertService) { }

  ngOnInit() {
    this.setForm();
  }

  private setForm(): void {
    this.form = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword : [null,Validators.required]
    },{
      validators: CustomValidator.passwordMatch('password','confirmPassword')
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit():void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.resetPassword(this.form.value).subscribe(response=>{
        this.alert.show(response.message,response.success);
        this.router.navigate([response.redirect]);
      });
    }
  }

}
