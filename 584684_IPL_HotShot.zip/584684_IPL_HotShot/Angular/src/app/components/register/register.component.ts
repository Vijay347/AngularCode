import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomValidator } from '@services/custom-validator.service';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  form: FormGroup;
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private router:Router, private auth:AuthService, private alert:AlertService) { }

  ngOnInit() {
    this.setForm();
  }

  private setForm(): void {
    this.form = this.fb.group({
      name : [null, [Validators.required, Validators.minLength(3)]],
      email: [null,[Validators.required,CustomValidator.email]],
      password : this.fb.control('', [Validators.required, Validators.minLength(8)]),
      confirmPassword : [null,Validators.required]
    },{
      validators: CustomValidator.passwordMatch('password','confirmPassword')
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit():void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.register(this.form.value).subscribe(response=>this.router.navigate([response.redirect]),error=>{
        Object.keys(error.error).forEach(key=>this.form.get(key).setErrors({remote: error.error[key]}));
      });
    }
  }

}
