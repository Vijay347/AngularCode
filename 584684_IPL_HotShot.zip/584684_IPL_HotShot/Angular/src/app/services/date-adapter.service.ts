import { Injectable } from '@angular/core';
import { NgbDateStruct, NgbDateNativeUTCAdapter } from '@ng-bootstrap/ng-bootstrap';

@Injectable({
  providedIn: 'root'
})
export class DateAdapterService extends NgbDateNativeUTCAdapter {

  fromModel(date: Date | string): NgbDateStruct {
    let dt = typeof date === 'string' ? new Date(date) : date;
    return (dt instanceof Date && !isNaN(dt.getTime())) ? this._fromNativeDate(dt) : null;
  }

}