import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class CustomValidator {

  static url(control: AbstractControl): ValidationErrors {
    if(!control.value){
      return null;
    }
    return /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})).?)(?::\d{2,5})?(?:[/?#]\S*)?$/i.test(control.value) ? null : { 'url': true };
  };

  static email(control: AbstractControl): ValidationErrors {
    if(!control.value){
      return null;
    }
    return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i.test(control.value) ? null : { 'email': true };
  };

  static minText = (minLength): ValidatorFn => {
    return (control: AbstractControl): ValidationErrors => {
      if(control.value){
        let element = document.createElement('DIV');
        element.innerHTML = control.value;
        if(!element.textContent.trim() || (element.textContent.trim() && element.textContent.trim().length >= minLength)){
          return null;
        }else{
          return {
            minText : true
          };
        }
      }else{
        return null;
      }
    };
  };

  static passwordMatch(controlOne:string, controlTwo:string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors => {
      return control.get(controlOne).value === control.get(controlTwo).value ? null : { equalTo: true };
    };
  };

  static greaterThanDate(minDate:string, maxDate:string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors => {
      let min = control.get(minDate).value;
      let max = control.get(maxDate).value;
      if(min && max){
        if(new Date(min) < new Date(max))
          return null;
        else
          return { greaterThanDate : true };
      }else
        return null;
    };
  };

  static requiredIf = (otherControl: AbstractControl): ValidatorFn => {
    let subscribe = false;
    return (control: AbstractControl): ValidationErrors => {
      if (!subscribe) {
        subscribe = true;
        otherControl.valueChanges.subscribe(() => {
          control.updateValueAndValidity();
        });
      }
      if(otherControl.value){
        const v: string = control.value;
        if(!v || (Array.isArray(v) && v.length == 0)){
          return { 
            requiredIf: true
          }
        }else{
          return null;
        }
      }else{
        return null;
      }
    };
  };

  static requiredIfOther = (otherControl: AbstractControl): ValidatorFn => {
    let subscribe = false;
    return (control: AbstractControl): ValidationErrors => {
      if (!subscribe) {
        subscribe = true;
        otherControl.valueChanges.subscribe(() => {
          control.updateValueAndValidity();
        });
      }
      if(otherControl.value){
        let isRequired = otherControl.value.some((value)=>{
          return value.name.includes('Other');
        });
        const v: string = control.value;
        if((!v || (Array.isArray(v) && v.length == 0)) && isRequired){
          return { 
            requiredIfOther: true
          }
        }else{
          return null;
        }
      }else{
        return null;
      }
    };
  };

  static jobLocation(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors => {
      const control1 = control.get('jobLocations');
      const control2 = control.get('jobCountriesId');
      const validateCountries = control.get('showCountries').value;
      if((!control1.value || (Array.isArray(control1.value) && control1.value.length == 0)) && (!control2.value || (Array.isArray(control2.value) && control2.value.length == 0))){
        control1.setErrors({ required: true });
        control2.setErrors({ required: true });
      }else{
        control1.setErrors(null);
        if(validateCountries && (!control2.value || (Array.isArray(control2.value) && control2.value.length == 0))){
          control2.setErrors({ required: true });
        }else{
          control2.setErrors(null);
        }
      }
      return null;
    };
  };



}
