import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbDateAdapter, NgbPaginationModule, NgbModalModule, NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEye, faPaperPlane } from '@fortawesome/free-regular-svg-icons';
import { faSignInAlt, faBars, faChevronCircleRight, faExclamationTriangle, faSearch, faUser, faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons';
library.add(faSignInAlt, faEye, faBars, faPaperPlane, faChevronCircleRight, faExclamationTriangle, faSearch, faSignInAlt, faUser, faChevronRight, faChevronLeft, faBars);
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { DateAdapterService } from '@services/date-adapter.service';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';
import { InterceptorService } from '@services/interceptor.service';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { GuestGuard } from '@guards/guest.guard';
import { AuthGuard } from '@guards/auth.guard';

import { AppComponent } from './app.component';
import { AlertComponent } from '@components/alert/alert.component';
import { RegisterComponent } from '@components/register/register.component';
import { LoginComponent } from '@components/login/login.component';
import { ForgotPasswordComponent } from '@components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '@components/reset-password/reset-password.component';
import { DashboardComponent } from '@components/dashboard/dashboard.component';
import { BatsmanScoreComponent } from '@components/batsman-score/batsman-score.component';
import { BatsmanRankingComponent } from '@components/batsman-ranking/batsman-ranking.component';
import { NavbarComponent } from '@components/navbar/navbar.component';
import { BatsmanScoreChartComponent } from '@components/batsman-score-chart/batsman-score-chart.component';

@NgModule({
  declarations: [
    AppComponent,
    AlertComponent,
    RegisterComponent,
    LoginComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    DashboardComponent,
    BatsmanScoreComponent,
    BatsmanRankingComponent,
    NavbarComponent,
    BatsmanScoreChartComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FontAwesomeModule,
    NgbPaginationModule,
    NgbModalModule,
    ReactiveFormsModule,
    NgbDropdownModule,
    NgxChartsModule,
    BrowserAnimationsModule
  ],
  providers: [
    { provide: NgbDateAdapter, useClass: DateAdapterService },
    { provide: 'Window', useValue: window },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    },
    AuthService,
    AlertService,
    SeoService,
    AuthGuard,
    GuestGuard,
    CricketService,
  ],
  entryComponents: [
    AlertComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
